file_name = "Writer.txt"
with open(file_name, 'w') as file:
    file.write("// Wallace Tree Creator\n")
    
def write(str):
    with open(file_name, 'a') as file:
        file.write(str)

for i in range(0,31):
    write('assign w0_%d0 = data_A[%d] & data_B[0];\n' %(i,i))
write('assign w0_%d0 = ~(data_A[%d] & data_B[0]);\n' %(31,31))

write('assign mult_out[0] = w0_00;\n')

write("assign wc0_310 = 1'b1;\n")
for y in range(1,31):
    write('half_adder half_adder%d_0(.a(data_A[0] & data_B[%d]), .b(w%d_1%d), .s(w%d_0%d), .cout(wc%d_0%d));\n' %(y,y,y-1,y-1,y,y,y,y))
    for x in range (1,31):
        write('full_adder full_adder%d_%d(.a(data_A[%d] & data_B[%d]),.b(w%d_%d%d), .cin(wc%d_%d%d), .s(w%d_%d%d), .cout(wc%d_%d%d));\n' %(y,x,x,y,y-1,x+1,y-1,y,x-1,y,y,x,y,y,x,y))
    write('full_adder full_adder%d_%d(.a(~(data_A[%d] & data_B[%d])),.b(wc%d_%d%d), .cin(wc%d_%d%d), .s(w%d_%d%d), .cout(wc%d_%d%d));\n' %(y,31,31,y,y-1,31,y-1,y,31-1,y,y,31,y,y,31,y))
    write('assign mult_out[%d] = w%d_0%d;\n'%(y,y,y))

write('half_adder half_adder%d_0(.a(~(data_A[0] & data_B[%d])), .b(w%d_1%d), .s(w%d_0%d), .cout(wc%d_0%d));\n' %(31,31,31-1,31-1,31,31,31,31))
for x in range (1,31):
    write('full_adder full_adder%d_%d(.a(~(data_A[%d] & data_B[%d])),.b(w%d_%d%d), .cin(wc%d_%d%d), .s(w%d_%d%d), .cout(wc%d_%d%d));\n' %(31,x,x,31,31-1,x+1,31-1,31,x-1,31,31,x,31,31,x,31))
write('full_adder full_adder%d_%d(.a(data_A[%d] & data_B[%d]),.b(wc%d_%d%d), .cin(wc%d_%d%d), .s(w%d_%d%d), .cout(wc%d_%d%d));\n' %(31,31,31,31,31-1,31,31-1,31,31-1,31,31,31,31,31,31,31))
write('assign mult_out[%d] = w%d_0%d;\n'%(31,31,31))


for i in range (32,63):
    write('assign mult_out[%d] = w31_%d31;\n'%(i,i-31))

write("half_adder half_adderFINAL_0(.a(wc31_3131), .b(1'b1), .s(mult_out[63]), .cout(wcFINAL));\n")
