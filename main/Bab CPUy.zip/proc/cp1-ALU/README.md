# ALU Module

## Overview
This ALU module performs a variety of arithmetic and logical operations on two 32-bit operands based on a control opcode. The ALU supports addition, subtraction, bitwise operations, and shift operations. It also provides status flags indicating whether the result is less than, unequal, or if an overflow has occurred.

## Inputs
- `data_operandA` (32-bit): First input operand.
- `data_operandB` (32-bit): Second input operand.
- `ctrl_ALUopcode` (5-bit): Specifies the operation to be performed.
- `ctrl_shiftamt` (5-bit): Specifies the shift amount for shift operations.

## Outputs
- `data_result` (32-bit): The result of the ALU operation.
- `isNotEqual` (1-bit): Set to 1 if `data_operandA` is not equal to `data_operandB` (only for subtraction operation).
- `isLessThan` (1-bit): Set to 1 if `data_operandA` is less than `data_operandB` (only for subtraction operation).
- `overflow` (1-bit): Indicates whether an arithmetic overflow has occurred.

## Functional Blocks
- **Addition (`sum` block)**: Adds `data_operandA` and `data_operandB`, producing `w0` and setting the `overflowadd` flag.
- **Subtraction (`sub` block)**: Subtracts `data_operandB` from `data_operandA`, producing `w1` and setting the `overflowsub`, `isNotEqual`, and `isLessThan` flags.
- **Bitwise AND (`and_32_bit` block)**: Performs bitwise AND on `data_operandA` and `data_operandB`, producing `w2`.
- **Bitwise OR (`or_32_bit` block)**: Performs bitwise OR on `data_operandA` and `data_operandB`, producing `w3`.
- **Logical Shift Left (`sll` block)**: Performs left shift on `data_operandA` by `ctrl_shiftamt`, producing `w4`.
- **Arithmetic Shift Right (`sra` block)**: Performs arithmetic right shift on `data_operandA` by `ctrl_shiftamt`, producing `w5`.
- **Multiplexer (`mux_8` block)**: Selects the appropriate operation result based on `ctrl_ALUopcode[2:0]` and assigns it to `data_result`.
- **Overflow Logic**: Determines the overflow flag based on the operation (addition or subtraction).

## Other Notes
Get-ChildItem -Name -Filter *.v | Out-File -FilePath FileList.txt -Encoding Ascii
iverilog -Wimplicit -o sll.vvp -c .\FileList.txt
vvp .\sll.vvp

include subdirectory
Get-ChildItem -Recurse -Name -Filter *.v | Out-File -FilePath FileList.txt -Encoding Ascii