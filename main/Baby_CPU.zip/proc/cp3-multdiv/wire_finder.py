import re

file_name = "Writer.txt"
wire_set = set()

# Regular expressions to capture wire names
wire_patterns = [
    r'assign\s+(w\d+_\d+\d*)',
    r'assign\s+mult_out\[\d+\]\s*=\s*(w\d+_\d+\d*)',
    r'half_adder\s+\w+\((?:.*?\.s\((w\d+_\d+\d*)\)|.*?\.cout\((wc\d+_\d+\d*)\))',
    r'full_adder\s+\w+\((?:.*?\.s\((w\d+_\d+\d*)\)|.*?\.cout\((wc\d+_\d+\d*)\))',
    r'assign\s+(wc\d+_\d+\d*)',
    r'wc\d+_\d+\d*'
]

# Read the Verilog file and extract wire names
with open(file_name, 'r') as file:
    for line in file:
        for pattern in wire_patterns:
            matches = re.findall(pattern, line)
            for match in matches:
                if isinstance(match, tuple):
                    for m in match:
                        if m:
                            wire_set.add(m)
                else:
                    wire_set.add(match)

# Generate Verilog wire declarations with a newline after every 10 wires
with open("WireDeclarations.txt", 'w') as wire_file:
    wire_file.write("wire ")
    
    wire_list = sorted(wire_set)
    for i, wire in enumerate(wire_list):
        if i > 0 and i % 10 == 0:
            wire_file.write("\n      ")  # Indent for readability
        wire_file.write(f"{wire}, ")
    
    wire_file.write(";")
    wire_file.wire("wire wcFINAL;")


print("Wire declarations saved to WireDeclarations.txt")
