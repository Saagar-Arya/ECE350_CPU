# Processor
## Saagar Arya (sa553)

## Description of Design
A simple 5-stage CPU with ALU methods except for mult and div implemented. PC increments by 1 and nothing happens in the memory stage currently. Latches at each stage. Might need to edit memory stage when those instructions are implemented.

## Bypassing
Not implemented

## Stalling
Not implemented

## Optimizations
For ALU optimizations use README in cp1-ALU folder

## Bugs
No Bugs noticed yet