# Register File Module

## Overview
This Verilog module implements a 32-register file for a CPU. It consists of 31 general-purpose 32-bit registers, with register 0 fixed at zero. The module allows for controlled writing to registers and reading from two registers in parallel.

## Features
- 32 registers, each 32 bits wide
- Write enable control signal
- Supports simultaneous reading from two registers
- Reset functionality to clear all registers
- Register 0 is hardwired to zero

## Ports
### Inputs:
- `clock` (1-bit): Clock signal to synchronize operations.
- `ctrl_writeEnable` (1-bit): Enables writing to a register when high.
- `ctrl_reset` (1-bit): Clears all registers when high.
- `ctrl_writeReg` (5-bit): Specifies the register to write to.
- `ctrl_readRegA` (5-bit): Specifies the first register to read from.
- `ctrl_readRegB` (5-bit): Specifies the second register to read from.
- `data_writeReg` (32-bit): Data to write to the specified register.

### Outputs:
- `data_readRegA` (32-bit): Data read from the first specified register.
- `data_readRegB` (32-bit): Data read from the second specified register.
